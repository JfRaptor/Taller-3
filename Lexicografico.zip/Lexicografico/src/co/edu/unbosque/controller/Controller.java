package co.edu.unbosque.controller;
import co.edu.unbosque.view.Model;

import java.util.ArrayList;

import co.edu.unbosque.model.View;

public class Controller {
	
	Model model = new Model();
	View view = new View();
	public void alg() {
		ArrayList<String> arr = new ArrayList<String>();
		System.out.println("numero de strings a comparar");
		int nElements = view.getX();
		System.out.println("inserte la palabra 1");
		arr = view.arrList(arr);
		for(int i = 0;i<=nElements-1;i++) {
			System.out.println("inserte la palabra "+(i+1));
			
			arr = view.arrList(arr);
		}
		String[] arr1 = new String[nElements];
		arr1 = view.arrListToArr(arr);
		arr1 = model.sortArray(arr1);
		System.out.println(arr +" es el array original ");
		arr = view.arrToArrList(arr1, nElements);
		System.out.println( arr+  " es el array organizado");
	}
	

}
