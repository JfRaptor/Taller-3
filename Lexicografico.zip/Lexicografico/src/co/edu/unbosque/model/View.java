package co.edu.unbosque.model;
import java.util.Scanner;
import java.util.ArrayList;

public class View {
	Scanner cc = new Scanner(System.in);
	
	public String getStringa(){
		 String a = cc.nextLine();
		 return a ;
	}
	
	public String[] arrListToArr(ArrayList<String> list) {
		int len = list.size();
		String[] arr = new String[len];
		for(int i = 0; i<len;i++) {
			arr[i] = list.get(i);
		}
		return arr;
	}
	
	public ArrayList<String> arrList(ArrayList<String> arrList){
		arrList.add(getStringa());
		return arrList;
		
	}
	public int getX(){
		int x = cc.nextInt();
		return x;
		
	}
	
	public ArrayList<String> arrToArrList(String[] arr1, int nE){
		 ArrayList<String> arr = new  ArrayList<String>();
		 for(int i = 0; i<=nE;i++) {
			 arr.add(arr1[i]);
		 }
		 return arr;
	}

}
