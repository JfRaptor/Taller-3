package co.edu.unbosque.control;
import co.edu.unbosque.model.*;
import co.edu.unbosque.view.*;
import java.util.ArrayList;

public class Control {
	
	View view = new View();
	Model model = new Model();
	public void alg() {
		ArrayList<Integer> arr = new ArrayList<Integer>();
		ArrayList<Integer> arReverse = new ArrayList<Integer>();
		System.out.println("que tan grande es el array que desea reversear");
		int i = view.getX();
		arr = view.getArrValues(i);
		System.out.println("su array original es: "+arr);
		arReverse = model.reverseArray(arr);
		System.out.println("su array reverseado es: "+arReverse);
		
		
		
	}
}
