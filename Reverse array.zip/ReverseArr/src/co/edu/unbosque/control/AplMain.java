package co.edu.unbosque.control;

public class AplMain {
	public static void main(String[] args) {
		Control cc = new Control();
		cc.alg();
	}
}
