package co.edu.unbosque.view;
import java.util.ArrayList;
import java.util.Scanner;
public class View {
	Scanner cc = new Scanner(System.in);
	
	public ArrayList<Integer> getArrValues(int i){
		ArrayList<Integer> arr = new ArrayList<Integer>();
		for(int j =1;j<=i;j++) {
			System.out.println("valor: "+j);
			int x = getX();
			arr.add(x);
		}
		return arr;
	}
	
	public int getX() {
		int x = cc.nextInt();
		return x;
	}

}
