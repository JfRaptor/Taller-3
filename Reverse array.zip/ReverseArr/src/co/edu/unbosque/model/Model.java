package co.edu.unbosque.model;
import java.util.ArrayList;

public class Model {
	
	public ArrayList<Integer> reverseArray(ArrayList<Integer> arr){
		int len = arr.size();
		ArrayList<Integer> arReverse = new ArrayList<Integer>();
		for(int i = len-1;i>=0;i=i-1) {
			arReverse.add(arr.get(i));
		}
		return arReverse;
	}
	

}
