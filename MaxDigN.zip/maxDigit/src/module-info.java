/**
 * 
 */
/**
 * 
 */
module maxDigit {
}