package co.edu.unbosque.model;
import java.util.Arrays;

public class Model {
	public char maxInArr(char[] arr) {
		Arrays.sort(arr);
		int len = arr.length;
		char max = arr[len-1];
		return max;
	}

}
