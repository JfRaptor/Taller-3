package co.edu.unbosque.view;
import java.util.Scanner;

public class View {
	Scanner cc = new Scanner(System.in);
	
	public int getN(){
		int n = cc.nextInt();
		return n ;
	}
	
	public int nLen(int n) {
		String nS = String.valueOf(n);
		int nLen = nS.length();
		return nLen;
	}
	
	public char[] ntoCharArr(int n) {
		String nS = String.valueOf(n);
		int len = nLen(n);
		char[] Narr = new char[len];
		Narr = nS.toCharArray();
		return Narr;
	}
	
	
}
