package co.edu.unbosque.controller;
import co.edu.unbosque.view.View;
import co.edu.unbosque.model.Model;

public class Controller {
	Model model = new Model();
	View view = new View();
	
	public void alg() {
		System.out.println("dijite su N");
		int n = view.getN();
		int len = view.nLen(n);
		char[] arr = new char[len];
		arr = view.ntoCharArr(n);
		char mxChar = model.maxInArr(arr);
		System.out.println("el dijito maximo de su N es "+mxChar);
		
	}
	

}
