package co.edu.unbosque.control;
import co.edu.unbosque.view.View;
import co.edu.unbosque.model.Model;


public class Controller {
	Model model = new Model();
	View view = new View();
	public void run(){
		System.out.println("dijite el primer numero en binario");
		String aStr = view.getXbin();
		System.out.println("dijite el segundo numero en binario");
		String bStr = view.getXbin();
		String res = model.addBinary(aStr, bStr);
		System.out.println("el resultado de la suma entre "+aStr+" + "+bStr+" es igual a "+res);
		
	}

}
