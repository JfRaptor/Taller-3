package co.edu.unbosque.controller;
import co.edu.unbosque.view.View;
import co.edu.unbosque.model.Model;

public class Controller {
	Model model = new Model();
	View view = new View();
	 public void alg() {
		 System.out.println("dijite su sufijo");
		 String st1 = view.getST();
		 System.out.println("dijite la palabra");
		 String st2 = view.getST();
		 if(model.sufijoChecker(st1, st2)) {
			 System.out.println(st1+" es el sufijo de "+st2);
		 }
		 else System.out.println(st1+" no es el sufijo de "+st2);
		 
		 
	 }

}
