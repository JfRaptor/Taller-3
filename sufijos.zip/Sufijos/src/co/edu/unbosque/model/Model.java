package co.edu.unbosque.model;

public class Model {
	
    public int sufijo(String st1, String st2){
        int m = st1.length();
        int n = st2.length();
 
        for (int i = 0; i <= n - m; i++) {
            int j;
 
            for (j = 0; j < m; j++)
                if (st2.charAt(i + j) != st1.charAt(j))
                    break;
            	if (j == m)
            		return i;
        }	
        return -1;
    }
    
    public boolean sufijoChecker(String st1, String st2) {
    	int m = st1.length();
        int n = st2.length();
        int x = sufijo(st1,st2);
        if(x==n-m) {
        	return true;
        }
    	
        else return false;
    	
    }
    
    
    
    
    
}
