package co.edu.unbosque.control;
import java.util.ArrayList;

import co.edu.unbosque.model.*;
import co.edu.unbosque.view.*;

public class Control {
	View view = new View();
	Model model = new Model();
	public void alg() {
		System.out.println("seleccione el numero de resultados que desea obtener");
		int n = view.getN();
		ArrayList<Integer> resultados = new ArrayList<Integer>(); 
		resultados = model.numerosCubos(n);
		System.out.println(resultados);
	}
}
