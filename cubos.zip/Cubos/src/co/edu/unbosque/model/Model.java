package co.edu.unbosque.model;
import java.util.ArrayList;
public class Model {
	
	public ArrayList<Integer> numerosCubos(int n ) {
		ArrayList<Integer> resultados = new ArrayList<Integer>(); 
		int impar = -1;
		for (int i = 1; i <= n; i++) {

			impar = impar + 2;
			int suma = impar;
			for (int j = 2; j <= i; j++) {
					impar = impar + 2;
					suma = suma + impar;
				}
			resultados.add(suma);
			}
		
		return resultados;
	}

}

