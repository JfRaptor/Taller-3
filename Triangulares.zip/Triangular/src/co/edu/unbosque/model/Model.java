package co.edu.unbosque.model;


public class Model {
	public int returnTriagNumb(int n) {
		int triag =(n*(n+1))/2;
		return triag;
	}
	
	
}
