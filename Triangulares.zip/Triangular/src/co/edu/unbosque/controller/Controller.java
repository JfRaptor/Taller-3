package co.edu.unbosque.controller;
import java.util.ArrayList;
import co.edu.unbosque.model.*;
import co.edu.unbosque.view.*;

public class Controller {
	
	View view = new View();
	Model model = new Model();
	
	public void alg() {
		ArrayList<Integer> nTriagArr = new ArrayList<Integer>();
		System.out.println("inserte el numero de numeros triangulares que desea hayar");
		int n = view.getN();
		for(int i = 1; i<=n;i++) {
			nTriagArr.add(model.returnTriagNumb(i));
		}
		System.out.println("sus numeros Triangulares son"+ nTriagArr);
		
		
	}
	
	

}
