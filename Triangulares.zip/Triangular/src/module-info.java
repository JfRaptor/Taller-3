/**
 * 
 */
/**
 * 
 */
module Triangular {
}