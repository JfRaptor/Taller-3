package co.edu.unbosque.model;
import java.util.ArrayList;

public class Model {
	
	public ArrayList<Integer> primeFactors(int n){
		ArrayList<Integer> factors = new ArrayList<Integer>();
		assert n>1;
		int i = 2;
		while(i<=n) {
			if(n%i==0) {
				factors.add(i);
				n = n/i;
			}
			i++;
		}
		return factors;
	}
	

}
