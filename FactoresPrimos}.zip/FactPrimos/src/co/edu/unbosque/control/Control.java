package co.edu.unbosque.control;
import co.edu.unbosque.view.*;
import co.edu.unbosque.model.*;
import java.util.ArrayList;
public class Control {
	public void alg() {
		View view = new View();
		Model model = new Model();
		System.out.println("ingrese el numero que desea descomponer");
		int n = view.getN();
		ArrayList<Integer> factors = new ArrayList<Integer>();
		factors = model.primeFactors(n);
		System.out.println("su descompocicion es "+factors);
		
		
	} 
}
