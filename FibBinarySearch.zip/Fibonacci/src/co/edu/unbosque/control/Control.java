package co.edu.unbosque.control;
import co.edu.unbosque.model.Model;
import co.edu.unbosque.view.View;
import java.util.ArrayList;

public class Control {
	Model model = new Model();
	View view = new View();
	
	public void alg() {
		ArrayList<Integer> fib = new ArrayList<Integer>();
		System.out.println("ingrese el valor de n1");
		int n1 = view.getN(); 
		System.out.println("ingrese el valor de n2");
		int n2 = view.getN();
		fib = view.setFib();
		if (model.isN1andN2inFib(n1, n2, fib)){
			System.out.println(n1+" y "+n2+" estan dentro de la secuencia de fibonacci juntos");
		}
		else System.out.println(n1+" y "+n2+"  no estan dentro de la secuencia de fibonacci juntos");
		if (model.isNinFib(n1,fib)){
			System.out.println(n1+" esta dentro de la secuencia de fibonacci");
		}
		else System.out.println(n1+" no esta dentro de la secuencia de fibonacci ");
		
		if (model.isNinFib(n2,fib)){
			System.out.println(n2+" esta dentro de la secuencia de fibonacci ");
		}
		else System.out.println(n2+"  no esta dentro de la secuencia de fibonacci ");
	}

}
