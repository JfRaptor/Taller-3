package co.edu.unbosque.view;
import java.util.Scanner;
import java.util.ArrayList;


public class View {
	Scanner cc = new Scanner(System.in);
	
	
	public int getN(){
		int n = cc.nextInt();
		return n ;
	}
	
	public ArrayList<Integer> setFib(){
		ArrayList<Integer> fib = new ArrayList<Integer>();
		fib.add(1);
		fib.add(1);
		int i = 0;
		while(i<80) {
			int cn = fib.get(i) + fib.get(i+1); 
			fib.add(cn);
			i++;
		}
		return fib;
	}

}


