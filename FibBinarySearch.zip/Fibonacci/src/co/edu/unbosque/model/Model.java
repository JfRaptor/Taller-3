package co.edu.unbosque.model;
import java.util.ArrayList;


public class Model {
	
	int binarySearch(ArrayList<Integer> arr, int x){
	int l = 0 ,r = arr.size()-1;
		while (l <= r) {
			int m = l + (r - l) / 2;
		// Check if x is present at mid
			if (arr.get(m) == x)
				return m;
		 
		// If x greater, ignore left half
			if (arr.get(m)< x)
				l = m + 1;
		 
		// If x is smaller, ignore right half
			else
				r = m - 1;
		}
	    // If we reach here, then element was not present
	return -1;
	}
	
	public boolean isN1andN2inFib(int n1,int n2,ArrayList<Integer> arr){
		int index1 = binarySearch(arr,n1);
		int index2 = binarySearch(arr,n2);
		if(index2 == 1 && index1 ==1) {
			return true;
		}
		else if(index2 == index1 +1) {
			return true ;			
		}
		else return false;
	}
	public boolean isNinFib(int n, ArrayList<Integer>arr) {
		int index = binarySearch(arr,n);
		if(index != -1) {
			return true;			
		}
		else return false;
	}
		
}


